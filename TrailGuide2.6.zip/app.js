var http = require('http');
var fs = require('fs');
var express = require("express");
var dotenv = require('dotenv');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var session = require('express-session');
var passport = require('passport');
var saml = require('passport-saml');
var os = require('os');
var fqdn = require('node-fqdn');



dotenv.load();


passport.serializeUser(function(user, done) {
  done(null, user);
});

passport.deserializeUser(function(user, done) {
  done(null, user);
});

var app = express();

app.use(cookieParser());
app.use(bodyParser());
app.use(session({secret: process.env.SESSION_SECRET}));
app.use(passport.initialize());
app.use(passport.session());

        //Saml Strategy that dynamically changes based on where the user came from
        var samlStrategy = new saml.Strategy({
          // URL that goes from the Identity Provider -> Service Provider (Our own address)
          callbackUrl: process.env.CALLBACK_URL,
          // URL that goes from the Service Provider -> Identity Provider (Client Address)
          entryPoint: process.env.ENTRY_POINT,
          // Usually specified as `/shibboleth` from site root
          issuer: process.env.ISSUER,
          identifierFormat: null,
          // Service Provider private key
          decryptionPvk: fs.readFileSync('cert/key.pem', 'utf8'),
          // Service Provider Certificate
          privateCert: fs.readFileSync('cert/key.pem', 'utf8'),
          // Identity Provider's public key
          cert: fs.readFileSync('cert/idp_cert.pem', 'utf8'),
          validateInResponseTo: false,
          disableRequestedAuthnContext: true
        }, function(profile, done) {
          return done(null, profile); 
        });

        //Allow passport to use the new samlStrategy
        passport.use(samlStrategy);

/* Start of my own code 
--------------------------------------------------------

//Application starting zone
//Example URL: www.example.com/basecamp?clientname=
app.get('/basecamp', function(req, res){
    
    //clientName will be the name of the Identity provider
    var clientName = req.query.clientname;
    var clientUrl= '';
    console.log('User from ' + clientName + ' asked for a tour guide.');
    
    //Hard coded checking. 
    //for better results a database or file could be used with a for each loop.
    if (clientName == "SSOCircle"){
        this.clientUrl = 'https://www.ssocircle.com/en/';
        
        res.redirect('/');
    }
    else{
        res.redirect('failed');
    }
    
})


/*----------------------------------------------
    Need to figure out how this RIT app begins the SAML process, and what the redirects do
    1. put console logs in each app.get to find out where it bounces around
    2. Figure out how to add more lines to .env (by either hard coding or inset)
    3. See if theres a more condensed version on how to go through .env (loops?)
    4. See if I can implement a logout
-------------------------------------------------*/


/*End of my own code
-------------------------------------------------------*/

function ensureAuthenticated(req, res, next) {
    
  if (req.isAuthenticated())
      //Maybe put Rock's code in here?
    return next();
  else
    return res.redirect('/login');
}

app.get('/', ensureAuthenticated, 
  function(req, res) {
    res.send('Authenticated');
  }
);

app.get('/home',function(req,res){
    res.sendFile('index.html', {root: __dirname });
        var hostname = os.hostname();
    console.log("The host name is: " + hostname);
    
    
    console.log("The fqdn is:" + fqdn());

})

app.get('/login',
  passport.authenticate('saml', { failureRedirect: '/login/fail' }),
  function (req, res) {
    res.redirect('/');
  }
);

app.post('/login/callback',
   passport.authenticate('saml', { failureRedirect: '/login/fail' }),
  function(req, res) {
    res.redirect('/');
  }
);

app.get('/login/fail', 
  function(req, res) {
    res.status(401).send('Login failed');
  }
);

app.get('/Shibboleth.sso/Metadata', 
  function(req, res) {
    res.type('application/xml');
    res.status(200).send(samlStrategy.generateServiceProviderMetadata(fs.readFileSync('cert/cert.pem', 'utf8')));
  }
);

//general error handler
app.use(function(err, req, res, next) {
  console.log("Fatal error: " + JSON.stringify(err));
  next(err);
});

var server = app.listen(8081, function () {
  console.log('Listening on port %d', server.address().port)
});

